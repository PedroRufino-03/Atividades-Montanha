public class Cliente {
    public String nome;
    public int idade;
    public Cliente(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public String toString() {
        return nome + ";" + idade;
    }

}