public class App {
    public static void main(String[] args) throws Exception {
        int i = 1;

        while (i <= 50) {
            System.out.println(i);
            i++;
        }
    }
}
