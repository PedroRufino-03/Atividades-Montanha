import java.util.Random;
import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        Random random = new Random();

        int numeroSorteado = random.nextInt(20) + 1;

        int palpite;
        int tentativas = 0;

        do {
        
            System.out.println("adivinhe o número entre 1 e 20: ");
            palpite = scanner.nextInt();

            tentativas++;

            if (palpite > numeroSorteado) {
                System.out.println("O número sorteado é menor que " + palpite + ". Tente novamente.");
            } else if (palpite < numeroSorteado) {
                System.out.println("O número sorteado é maior que " + palpite + ". Tente novamente.");
            }
        } while (palpite != numeroSorteado);

        System.out.println("Parabéns! você acertou o número em " + tentativas + " tentativas.");
    }
}
