import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        
        String senha = "1234";

        System.out.println("===Digite sua senha para acessar o sistema===");
        String senhadigitada = scanner.nextLine();
       
        while (!senhadigitada.equals(senha)){
            System.out.println("Acesso negado");
            
            System.out.println("Digite sua senha novamente: ");
            senhadigitada = scanner.nextLine();
        }  
        
        System.out.println("acesso concedido");
        
        }
    }

