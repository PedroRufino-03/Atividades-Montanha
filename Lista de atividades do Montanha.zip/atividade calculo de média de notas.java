import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        double nota = 0;
        double somanotas = 0;
        int quantidadedenotas = 0;
        String resposta;

        do{
           System.out.println("Digite uma nota de 0 a 10: ");
           nota = scanner.nextDouble();

           if (nota >= 0 && nota <= 10) {
            somanotas += nota;
            quantidadedenotas ++;

           } else {
            System.out.println("Nota inválida! Digite uma nota entre 0 e 10.");

           }

           System.out.println("Deseja inserir outra nota? (sim/não)");
           scanner.nextLine();
           resposta = scanner.nextLine();

        } while (resposta.equalsIgnoreCase("sim"));

        if (quantidadedenotas > 0) {
            double media = somanotas / quantidadedenotas;
            System.out.println("A média das notas inseridas é: " + media);
        } else {
            System.out.println("Nenhuma nota válida foi inserida.");
        }

        }
    }

