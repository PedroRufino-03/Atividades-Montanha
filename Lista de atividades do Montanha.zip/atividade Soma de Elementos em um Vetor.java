import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        
        int[] vetor = new int[10];

        System.out.println("digite 10 números inteiros: ");

        for (int i = 0; i <10; i++) {
            System.out.println("Número " + (i + 1) + ": ");
            vetor[i] = scanner.nextInt();
        }

        int somaTotal = 0;
        for (int i = 0; i < vetor.length; i++) {
            somaTotal += vetor[i];
        }

        System.out.println("A soma total dos elementos do vetor é: " + somaTotal);

        scanner.close();
    }
}
