public class App {
    public static void main(String[] args) throws Exception {
        int a = 0;
        int b = 1;

        int contador = 0;

        while (contador < 10) {
            System.out.println(a);

            int x = a;
            a = b;
            b = x + b;

            contador++;
        }
    }
}
