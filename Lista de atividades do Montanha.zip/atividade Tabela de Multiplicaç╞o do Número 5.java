public class App {
    public static void main(String[] args) throws Exception {
        
        System.out.println("***TABUADA DO 5***");

        int i = 1;
        int numero = 5;

        for (; i <= 10; i++) {
            int resultado = numero * i;
            System.out.println(numero + "x" + i + "=" + resultado);
        }
    }
}
