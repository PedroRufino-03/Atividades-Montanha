public class App {
    public static void main(String[] args) throws Exception {
        for (int i = 1; i <= 100; i++) {
        
            if (i % 2 != 0) {
                System.out.print(i);
                if (i < 99); {
                    System.out.print(", ");
                }
            }
        }
    }
}

