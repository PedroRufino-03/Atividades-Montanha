import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        
        int opção;

        do {
            System.out.println("***MENU***");
            System.out.println("1. Adicionar");
            System.out.println("2. Remover.");
            System.out.println("3. Sair.");
            opção = scanner.nextInt();

            if (opção == 1) {
            System.out.println("A opção 'adicionar' foi selecionada");
             
            }else if (opção == 2){
             System.out.println("A opção 'remover' foi selecionada.");
            
            }else if (opção == 3) {
                System.out.println("Encerrando programa.");
            
            } else {
                System.out.println("Opção inválida!");
            } 
        } while (opção != 3);
    }
}
