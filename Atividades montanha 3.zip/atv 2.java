import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        int numeros [] = new int[15];

        for (int i = 0; i < numeros.length; i++) {
            System.out.println(" Digite o número da posição " + (i + 1) + ":");
            numeros[i] = scanner.nextInt();
        }
        
        int maior = numeros[0];
        int indiceMaior = 0;

        for (int i = 1; i < numeros.length; i++) {
            if (numeros[i] > maior) {
                maior = numeros[i];
                indiceMaior = i;
            }
        }
        System.out.println("O maior valor é: " + maior + " e está na posição " + (indiceMaior + 1));
    }
}
