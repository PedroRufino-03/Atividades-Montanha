import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        int[] A = new int[5];
        System.out.println("Digite 5 números para o vetor A: ");
        for (int i = 0; i < A.length; i++) {
            System.out.print("A[" + i + "]: ");
            A[i] = scanner.nextInt();
        }

        int[] B = new int[5];
        System.out.println("Digite 5 números para o vetor B: ");
        for (int i = 0; i < B.length; i++) {
            System.out.print("B[" + i + "]: ");
            B[i] = scanner.nextInt();
        }

        Set<Integer> setC = new LinkedHashSet<>();

        for (int num : A) {
            setC.add(num);
        }
        for (int num : B) {
            setC.add(num);
        }

        int[] c = new int[setC.size()];
        int idx = 0;
        for (int num : setC) {
            c[idx++] = num;
        }

        System.out.println("Vetor C = ");
        for (int i = 0; i < c.length; i++) {
            System.out.println(c[i] + (i < c.length - 1 ? ", " : "\n"));
        }
    }
}
