import java.util.Scanner; 
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        int[] vetor = new int[8];

        System.out.println("Digite 8 números: ");


        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Número " + (i + 1) + ": ");
            vetor[i] = scanner.nextInt();
        }

        System.out.println("Vetor na ordem inersa: ");
        for (int i = vetor.length - 1; i >= 0; i--) {
            System.out.println(vetor[i] + " ");
        }
    }
}
