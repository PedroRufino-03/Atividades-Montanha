import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        int[] vetor = new int[10];

        System.out.println("Digite 10 números inteiros: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            vetor[i] = scanner.nextInt();
        }

        System.out.println("Digite o número que deseja remover: ");
        int remover = scanner.nextInt();

        int indiceRemover = -1;
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] == remover) {
                remover = i;
                break;
            }
        }

        if (remover == -1) {
            System.out.println("Número não encontrado no vetor.");
        } else {
            int[]novoVetor = new int[vetor.length - 1];
            int a = 0;
            for (int i = 0; i < vetor.length; i++) {
                if (i != remover) {
                    novoVetor[a++] = vetor[i];
                }
            }

            System.out.println("Vetor após remoção: ");
            for (int num : novoVetor) {
                System.out.print(num + " ");
            }
        }
    }
}
