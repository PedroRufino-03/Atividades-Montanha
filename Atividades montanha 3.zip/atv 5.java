import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        double [] numeros = new double[12];
        double soma = 0;

        System.out.println("Digite 12 números: ");
        for(int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i+1) + ": ");
            numeros[i] = scanner.nextDouble();
            soma = soma + numeros[i];
        }

        double media = soma / numeros.length;
        int contador = 0;

        for (double num : numeros) {
            if (num > media) {
                contador++;
            }
        }

        System.out.println("Média dos valores: " + media);
        System.out.println("Quantidade de elementos maiores que a média: " + contador);
    }
}
