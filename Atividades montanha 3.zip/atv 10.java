import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        int [] vetor = new int[10];
        
        System.out.println("Digite 10 números inteiros: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("Número #" + (i + 1) + ": ");
            vetor[i] = scanner.nextInt();
        }

        for (int j = 0; j < vetor.length -1; j++) {
            for (int h = 0; h < vetor.length - 1 - j; h++)
            if (vetor[h] > vetor[h + 1]) {
                int temp = vetor [h];
                vetor[h] = vetor[h + 1];
                vetor [ h + 1] = temp;
            }
        }

        System.out.println("Vetor ordenado em ordem crescente: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.println(vetor[i] + (i < vetor.length - 1 ? ", " : "\n"));
        }
    }
}
