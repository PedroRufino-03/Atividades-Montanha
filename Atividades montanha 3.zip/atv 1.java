public class App {
    public static void main(String[] args) throws Exception {
        int [] numeros = {2,4,6,7,12,14,16,32,90,1};

        int soma = 0;

        for (int i = 0; i < numeros.length; i++) {
            soma = soma + numeros[i];
        }
        System.out.println("A soma dos elementos do vetor é: " + soma);
    }
}
