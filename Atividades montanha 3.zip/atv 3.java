public class App {
    public static void main(String[] args) throws Exception {
        
        int[] numero = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
        int soma = 0;
        
        System.out.println("=====================================================================");
        System.out.println("Dada a sequencia '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20'.");
        System.out.println("Os números pares presentes na sequência são: ");
        for (int i = 0; i < numero.length; i++) {
            if (numero[i] % 2 == 0){
                System.out.print(numero[i] + ", ");
                soma++;
            }
        }
        System.out.println();
        System.out.println();
        System.out.println("A quantidade de números pares de 1 a 20 são: " + soma);
        System.out.println("=====================================================================");
        }
    }

