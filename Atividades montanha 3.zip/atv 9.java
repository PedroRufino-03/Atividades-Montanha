import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        Scanner scanner = new Scanner(System.in);

        int[] A = new int[6];
        System.out.println("Digite 6 números inteiros para o vetor A: ");
        for (int i = 0; i < A.length; i++) {
            System.out.print("A[" + i + "]: ");
            A[i] = scanner.nextInt();
        }

        int[] B = new int[6];
        System.out.println("Digite 6 números inteiros para o vetor B: ");
        for (int i = 0; i < B.length; i++) {
            System.out.print("B[" + i + "]: ");
            B[i] = scanner.nextInt();
        }

        Set<Integer> setA = new LinkedHashSet<>();
        for (int num : A) {
            setA.add(num);
        }

        Set<Integer> setC = new LinkedHashSet<>();
        for (int num : B) {
            if (setA.contains(num)) {
                setC.add(num);
            }
        }

        int[] C = new int[setC.size()];
        int idx = 0;

        for (int num : setC) {
            C[idx++] = num;
        }

        System.out.println("Vetor C: ");
        if (C.length == 0) {
            System.out.println("Não há elementos comuns.");
        } else {
            for (int i = 0; i < C.length; i++) {
                System.out.print(C[i] + (i < C.length - 1 ? ", " : "\n)"));
            }
        }
    }
}
