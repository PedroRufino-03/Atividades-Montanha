import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        int[] vetor = new int[15];

        System.out.println("Digite 15 números inteiros: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Número " + (i+1) + ": ");
            vetor[i] = scanner. nextInt();
        }

        System.out.println("Digite um número para contar ocorrências: ");
        int alvo = scanner.nextInt();

        int contagem = 0;
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] == alvo) {
                contagem++;
            }
        }

        System.out.println("número " + alvo + " aparece " + contagem + " vezes");
    }
}
